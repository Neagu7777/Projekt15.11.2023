package Funds;



public interface AbleToCalculatePension {
    double calculatePension();
}