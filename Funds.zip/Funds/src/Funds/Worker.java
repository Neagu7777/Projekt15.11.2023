package Funds;

import java.util.Objects;
import java.util.Set;


public class Worker extends Person implements AbleToCalculatePension {
    private int minSalary;
    private int maxSalary;
    private final static double PENSION_COEFFICIENT = 0.25;
    private final static double ADDITIONAL_COEFFICIENT = 0.05;
    private final static double COUNT_OF_PROFS = 3;
    private Set<Profession>professions;


    public Worker(String name, int age, double height, Gender gender) {
        super(name, age, height,gender);
        this.minSalary = minSalary;
        this.maxSalary = maxSalary;


    }



    // Static method for creating a Worker
    public static Worker createWorker(String name, int minSalary, int maxSalary, String gender) {
        // Assuming that Gender is an enum
        Gender genderEnum = Gender.valueOf(gender);

        return new Worker(name, minSalary, maxSalary, genderEnum);
    }

    // ... getters and other methods
//    public  Object Worker (String name,int minSalary, int maxSalary, String gender) {
//        this.setName(name);
//        this.setMinSalary(minSalary);
//        this.setMaxSalary(maxSalary);
//        this.setGender(Gender.valueOf(gender));
//        return new Worker(name,minSalary,maxSalary, gender);
//    }

    public int getMinSalary() {
        return minSalary;
    }

    public void setMinSalary(int minSalary) {
        this.minSalary = minSalary;
    }

    public int getMaxSalary() {
        return maxSalary;
    }

    public void setMaxSalary(int maxSalary) {
        this.maxSalary = maxSalary;
    }

    public Set<Profession> getProfessions() {
        return professions;
    }

    public void setProfessions(Set<Profession> professions) {
        this.professions = professions;
    }

    @Override
    public void die() {
        System.out.println("Этот человек не дожил до пенсии.");
    }


    @Override
    public void die(int age) {
        System.out.println("Этот человек не доживет до пенсии и умрет через " + age + " лет");
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        Worker worker = (Worker) o;
        return minSalary == worker.minSalary && maxSalary == worker.maxSalary && Objects.equals(professions, worker.professions);
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), minSalary, maxSalary, professions);
    }

    @Override
    public String toString() {
        return "Worker{" +
                "minSalary=" + minSalary +
                ", maxSalary=" + maxSalary +
                ", professions=" + professions +
                '}';
    }

    @Override
    public double calculatePension() {

        Gender gender = getGender();

        if (gender == null) {
            return 0.0;
        }

        double averageSalary;

        if (gender.equals(Gender.MALE)) {
            averageSalary = CalculatorUtils.calculateAverage(minSalary, maxSalary);
        } else {
            averageSalary = CalculatorUtils.calculateAverage(minSalary / 2, maxSalary * 2);
        }
        double additionalMoney = 0.00;
        if(professions != null){
            int coutProfession = professions.size();
            additionalMoney = 1 + coutProfession / COUNT_OF_PROFS * ADDITIONAL_COEFFICIENT;
        }
//      return averageSalary * PENSION_COEFFICIENT + (averageSalary * PENSION_COEFFICIENT * additionalMoney);
        return averageSalary * PENSION_COEFFICIENT * (1 + additionalMoney);
    }

}






