import java.io.*;
import java.util.List;
import java.util.stream.Collectors;

//public class WorkerGenerator {
//    public static void main(String[] args) throws IOException {
//        File generatedPeopleFile = new File("GeneratedPeople.txt");
//
//        try (BufferedReader bufferedReader = new BufferedReader(new FileReader(generatedPeopleFile))) {
//            List<Worker> workers = bufferedReader.lines()
//                    .map(line -> {
//                        String[] parts = line.split("\\s+");
//                        String name = parts[0];
//                        int minSalary = Integer.parseInt(parts[1]);
//                        int maxSalary = Integer.parseInt(parts[2]);
//                        String gender = parts[3];
//                        return Worker.createWorker(name, minSalary, maxSalary, gender);
//                    })
//                    .collect(Collectors.toList());
//
//            // Вывод информации о созданных объектах Worker
//            for (Worker worker : workers) {
//                System.out.println(worker);
//            }
//        }
//    }
//}
public class WorkerGenerator {
    public static void main(String[] args) throws IOException {
        File generatedPeopleFile = new File("GeneratedPeople.txt");

        try (BufferedReader bufferedReader = new BufferedReader(new FileReader(generatedPeopleFile))) {
            List<Worker> workers = bufferedReader.lines()
                    .map(line -> {
                        String[] parts = line.split("\\s+");
                        try {
                            String name = parts[0];
                            int minSalary = Integer.parseInt(parts[1]);
                            int maxSalary = Integer.parseInt(parts[2]);
                            String gender = parts[3];
                            return Worker.createFromData(name, minSalary, maxSalary, gender);
                        } catch (NumberFormatException | ArrayIndexOutOfBoundsException e) {
                            // Handle the exception (e.g., log, skip the line, or take appropriate action)
                            e.printStackTrace();
                            return null; // or some default Worker
                        }
                    })
                    .filter(worker -> worker != null) // Filter out null workers
                    .collect(Collectors.toList());

            // Вывод информации о созданных объектах Worker
            for (Worker worker : workers) {
                System.out.println(worker);
            }
        }
    }
}