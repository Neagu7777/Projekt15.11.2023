

import Funds.PensionFund;
import Funds.Worker;

import java.io.*;
import java.util.List;

public class PensionFundGenerator {
    public static void main(String[] args) throws IOException {


        File GeneratedFunds = new File("GeneratedFunds.txt");
        File GeneratedPensionFund = new File("GeneratedPensionFund.txt");

        FileReader fileReader = new FileReader(GeneratedFunds);
        FileWriter fileWriter = new FileWriter(GeneratedPensionFund);

        BufferedReader bufferedReader = new BufferedReader(fileReader);
        BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);

        List<PensionFund> pensionFunds = (List<PensionFund>) bufferedReader.lines();

    }
}

